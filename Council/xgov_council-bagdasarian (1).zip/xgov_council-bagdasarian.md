# xGov Council Application

**Full Name:** Bagdasarian Edgar Levonovich  
**GitHub Username:** Mredgarcrosss  
**Country:** Russia  
**Languages:** Russian (native), English (fluent)  
**KYC Status:** Will complete upon request  
**Term applying for:** 2025 xGov Council

---

## 🧠 About Me

I am a blockchain educator, investor, and content creator from Russia.  
Since Governance Period 3, I have actively participated in every governance cycle and voted in all eligible xGov sessions (2, 3, 4).  
My ALGO commitments consistently exceeded 100K ALGO — earning multiple “Whale Governor” and “OG Governor” NFTs from Pera Wallet.

My wallet: `OLCDWT4LQMKJAKVJDSMNQP7GKEBK2U2UNYSSENULPCWJUTTY4Y6EPEWHA`  
Asset ID example: `2961477172` — Pera Governance XIV NFT

I run the educational platform [https://mredgarcross.com](https://mredgarcross.com), where I provide detailed blockchain courses including Algorand staking, governance, wallets, xGov sessions, and Ledger integration.

🎓 Course: [Algorand & Ledger Education](https://mredgarcross.com/p/748310/)  
▶️ YouTube Playlist: [Algorand Governance Series](https://www.youtube.com/watch?v=mS4TvZI99fI&list=PL86CmUm0KxLxiRv-wtVQ_KwLaij0cU7Nt)

---

## 🎯 Why I'm Applying

xGov is a rare example of real decentralized governance. I believe it must be accessible, transparent, and high-quality — and I can help bring that vision to life.

I will:
- Evaluate proposals with an educator’s clarity and an investor’s precision  
- Promote quality through my media platforms  
- Represent non-English speaking regions in governance  
- Help simplify xGov for everyday users while maintaining its integrity

---

## 🔗 Public Profiles

- 🌐 Website: [https://mredgarcross.com](https://mredgarcross.com)  
- 🐙 GitHub: [https://github.com/Mredgarcrosss](https://github.com/Mredgarcrosss)  
- 🎥 YouTube: [https://www.youtube.com/@MREDGARCROSS](https://www.youtube.com/@MREDGARCROSS)  
- 🧑‍🏫 Algorand Course: [Ledger & Governance](https://mredgarcross.com/p/748310/)  
- 📣 Telegram: [@mredgarcross](https://t.me/mredgarcross)  
- 🐦 Twitter/X: [@mredgarcross](https://twitter.com/mredgarcross)
